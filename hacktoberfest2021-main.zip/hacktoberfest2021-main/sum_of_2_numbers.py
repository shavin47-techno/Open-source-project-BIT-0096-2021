x = float(input("Input first number:"))
y = float(input("Input second number:"))

sum = x+y
print(sum)
