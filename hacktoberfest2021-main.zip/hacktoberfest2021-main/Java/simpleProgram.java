class Main {
  public static void main(String[] args) {
    int product = 5 * 2;
    System.out.println(product);

    String name = "Flora";
    System.out.println(name);

    int expression = 7 + 3;
    System.out.println(expression);
   
    boolean isTrue = false;
    System.out.println(isTrue);
  }
}
