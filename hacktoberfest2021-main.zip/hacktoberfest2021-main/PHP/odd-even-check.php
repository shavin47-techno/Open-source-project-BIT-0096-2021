<?php

$number = 10; // Initialize

if ($number % 2 == 0){
    echo "This number $number is even"; //true
}else {
    echo "This number $number is odd"; //false
}
?>
