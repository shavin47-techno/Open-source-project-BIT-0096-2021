this is a small paper rock scissor game built for hacktoberfest with C#.
you must have the microsoft dotnet sdk to build and run.
have fun.