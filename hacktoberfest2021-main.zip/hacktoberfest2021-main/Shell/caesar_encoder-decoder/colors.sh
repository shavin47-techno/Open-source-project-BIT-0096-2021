#!/bin/bash
# Management of colors and fonts

export red="\033[31m"
export blue="\033[34m"
export magenta="\033[35m"

export default="\033[0m"
