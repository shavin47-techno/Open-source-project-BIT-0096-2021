l;
    cout<<s.pop()<<endl;