#include <bits/stdc++.h>
using namespace std;

int main(){
    long long inpt;
    cin>>inpt;
    for(int j=0;j<inpt;j++){
    long long temp,sum,x;
    cin>>temp>>sum;
    x=sum/((temp/2)+1);cout<<x<<endl;
    }return 0;
    
}