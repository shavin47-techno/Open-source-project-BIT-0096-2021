#include <iostream>
using namespace std;

int main()
{
  int a,b,c;
  cin>>a>>b>>c;
  int arr1[]={a,b,c};
  cout<<arr1[2];
  return 0;
  
}
