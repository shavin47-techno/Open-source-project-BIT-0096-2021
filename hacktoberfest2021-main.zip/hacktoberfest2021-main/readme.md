# Hacktober Fest 2021
![Hacktoberfest 2021](hacktoberfest2021.PNG)

<p align="center">
   <img alt="GitHub pull-requests" src="https://img.shields.io/github/issues-pr/namishkhanna/hacktoberfest2021"></a>
   <img alt="GitHub forks" src="https://img.shields.io/github/forks/namishkhanna/hacktoberfest2021"></a>
   <img alt="GitHub stars" src="https://img.shields.io/github/stars/namishkhanna/hacktoberfest2021"></a>
</p>

# Upload Different Types of Programs in any Language
Use this project to make your first contribution to an open source project on GitHub. Practice making your first pull request to a public repository before doing the real thing!

# What is Hacktoberfest?
Hacktoberfest is a program by Digital Ocean, DEV and Github, where you can easily win a T-Shirt just by making 4 pull requests in the month of October to any open source projects on Github.

## Steps to follow:

### 1. Register for Hacktoberfest
###### https://hacktoberfest.digitalocean.com/

### 2. Add a Program in any Language you like:
Add any Simple or Complex Program in any language you Like in this Repository by clicking "Add File -> Create new File".

### 3. Create Pull Request:
Once you have completed these steps, you are ready to start contributing by clicking on Create Pull Request.

### 4. Give this Project a Star:
If you liked working on this project, please share this project as much as you can and star this project to help as many people in opensource as you can.

## Note:
1. Don't Create Pull Request to update "readme.md" File.
2. Upload or Create File in Specified Language Folder.
3. If Specified Language Folder not Found then Create Folder and then Upload or Create File.
