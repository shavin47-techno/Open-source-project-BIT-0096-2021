//reverse of a string
#include <stdio.h>  

#include <string.h>  

int main()  

{  

    char str[40]; // declare the size of character string  

    printf (" \n Enter a string to be reversed: ");  

    scanf ("%s", str);  

      

    // use strrev() function to reverse a string  

    printf (" \n After the reverse of a string: %s ", strrev(str));  

    return 0;  

}  
