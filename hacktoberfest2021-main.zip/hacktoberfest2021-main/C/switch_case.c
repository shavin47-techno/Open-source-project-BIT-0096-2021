#include<stdio.h>
int main(int argc, char const *argv[])
{
    int a;
    printf("enter the number");
    scanf("%d", &a);

switch (a)
{
case 18:
    printf("u r eligible for vote");
    break;

    printf("u r not eligible for vote");
    break;
}
    return 0;
}
