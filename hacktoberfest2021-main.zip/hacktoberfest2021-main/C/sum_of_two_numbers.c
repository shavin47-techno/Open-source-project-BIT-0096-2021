#include<stdio.h>

int main()
{
    int a,b;
    printf("enter number a\n");
    scanf("%d",&a);

    printf("enter number b\n");
    scanf("%d",&b);

    printf("addition of a and b is %d",a+b);

    return 0;
}
