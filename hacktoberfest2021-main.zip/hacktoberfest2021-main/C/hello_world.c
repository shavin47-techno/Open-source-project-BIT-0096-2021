#include<stdio.h>

int main(int argc, char const *argv[])
{
printf("hello world");

return 0;
}